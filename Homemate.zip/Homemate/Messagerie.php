
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<style>
p
{
    color: blue;
}
</style>
<title>Premiers tests du CSS</title>
</head>

<body>
<h1>Mon super site</h1>

<p>Bonjour et bienvenue sur mon site !</p>
<p>Pour le moment, mon site est un peu <em>vide</em>. Patientez encore un peu !</p>
</body>
</html>