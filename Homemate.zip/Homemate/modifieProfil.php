<?php
if (isset($_POST['nom'])
	&&isset($_POST['prenom'])
	&&isset($_POST['statut'])
	&&isset($_POST['numAppartement'])
	&&isset($_POST['numRue'])
	&&isset($_POST['numBis'])
	&&isset($_POST['prefixRueBdAve'])
	&&isset($_POST['nomRueBdAve'])
	&&isset($_POST['departement'])
	&&isset($_POST['ville'])
	&&isset($_POST['email'])
	&&isset($_POST['numTel'])){
	try {	$bdd = new PDO('mysql:host=localhost;dbname=homemate;charset=utf8', 'root', '', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));}
	catch(Exception $e){	die('Erreur : '.$e->getMessage());}
/*INSERT INTO profil (Nom,Prenom,Statut,NumeroAppartement,NumeroEtage,NumeroRue,Bis,PrefixeRueAveBd,NomRueAveBd,NumeroDepartement,Ville,Email,NumeroTelephone) VALUES ('nom','preomn','Gérant',5,5,46,'avenue','Champs de Mars',71,'Paris','fr@fr.fr',32)*/
	$req = $bdd->prepare('INSERT INTO profil (Nom,Prenom,Statut,NumeroAppartement,NumeroEtage,NumeroRue,Bis,PrefixeRueAveBd,NomRueAveBd,NumeroDepartement,Ville,Email,NumeroTelephone) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)');
	$req->execute(array($_POST['nom'],
	$_POST['prenom'],
	$_POST['statut'],
	$_POST['numAppartement'],
	$_POST['numEtage'],
	$_POST['numRue'],
	$_POST['numBis'],
	$_POST['prefixRueBdAve'],
	$_POST['nomRueBdAve'],
	$_POST['departement'],
	$_POST['ville'],
	$_POST['email'],
	$_POST['numTel']));
	$req->closeCursor();
	echo 'vous avez bien enregistrer les modification';
}
else{
?>

	
<html>
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="miseEnPageProfil.css" />
        <title>Modifié votre profil</title>
    </head>

    <body>
    	<br />
    	<img src="logo.png" class="logo" alt="image du logo" href="pageDAccueil.php"/>
    	
    	<img src="iconeProfil.png" class="iconeProfil" alt="Icône Profil" href="pageDAccueil.php"/> <span class="profil">Profil</span>

		<img src="iconeDeconnection.png" class="boutonDeconnection" alt="bouton de déconnection" href="pageDAccueil.php"/>
    	
    	<div class="rectangle">
			<form action="modifieProfil.php" method="post" enctype="multipart/form-data">
				<p>
					Nom, Prénom, Statut: <br/>
					<input type="text" name="nom" placeholder="nom"/>
					<input type="text" name="prenom" placeholder="prénom" /><br/>
					<select name="statut">
						<option value="proprietaire">proprietaire</option>
						<option value="locataire">locataire</option>
						<option value="gestionnaire">gestionnaire</option>
					</select><br /><br/>
					Adresse complète:<br/>
					<input type="text" name="numAppartement" placeholder="numéro d'appartement" />
					<input type="text" name="numEtage" placeholder="numéro d'étage"/><br />
					<input type="text" name="numRue" placeholder="numéro de rue"/>
					<input type="checkbox" name="numBis" value="bis"/><label for="bis">bis</label>
					<select name="prefixRueBdAve">
						<option value="rue">rue</option>
						<option value="bd">boulevard</option>
						<option value="ave">avenue</option>
						<option value="imp">impasse</option>
						<option value="pond">pond</option>
					</select>
			
					<input type="text" name="nomRueBdAve" placeholder="nom de rue, boulevard ou avenue" /><br/>
					<input type="text" name="departement" placeholder="département" />
					<input type="text" name="ville" placeholder="ville"/></span><br/>
					Mail:<br/>
					<input type="text" name="email" placeholder="email"/><br/>
					Numéro de téléphone:<br/>
					<input type="text" name="numTel" placeholder="numéro de téléphone"/><br />
					<input type="submit" value="Envoyer les modifications" class="boutonEnvoyerModification"/><br />
					<a href="profil.html" >annulé</a>
				</p>
			</form>
			
    	<div/>
    </body>
</html>

<?php
}
?>
